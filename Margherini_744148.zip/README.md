## Installazione Cittadini
Aprire la cartella Cittadini nel terminale ed eseguire il comando
`mvn clean package` per generare il jar.

## Installazione Centri vaccinali
Aprire la cartella Centri Vaccinali nel terminale ed eseguire il comando
`mvn clean package` per generare il jar.

Il driver necessario per la comunicazione con il database viene incluso automaticamente nell'archivio jar.
