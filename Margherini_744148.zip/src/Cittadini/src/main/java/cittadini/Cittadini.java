/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package cittadini;

import gui.Gui;
import datamodel.*;
import interfaces.*;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.ArrayList;
import java.util.Date;

public class Cittadini  {
    private CentriVaccinaliInt server;
    private CittadinoRegistrato utente;
    private Vaccinato vaccinato;
    private Boolean logged=false;
    private Boolean admin=false;

    /**
     *Permette di impostare l'utente correntemente collegato
     * @param user l'utente che ha eseguito l'accesso
     */
    public void setUtente(CittadinoRegistrato user){
        utente=user;
        try {
            vaccinato=server.visualizzaInfoVaccinato(user.getIdVaccinazione());
            logged=true;
            if(utente.getUserId().equals("admin")){
                admin=true;
            }
        } catch (RemoteException | NullPointerException e) {
            vaccinato=null;
            logged=false;
            admin=false;
        }
    }

    /**
     * Restituisce l'utente correntemente collegato
     * @return Un oggetto di tipo <code>CittadinoRegistrato</code>
     */
    public CittadinoRegistrato getUtente(){
        return utente;
    }

    public static void main (String[] args){  
    	new Cittadini().exec();
    }
    public void exec(){
        try {
            Registry registry=LocateRegistry.getRegistry();
            server=(CentriVaccinaliInt) registry.lookup("Server");
        } catch (RemoteException | NotBoundException e) {
            throw new RuntimeException(e);
        }
        new Gui(this);
    }
    public Boolean registraCentroVaccinale(String nome,String comune, String indirizzo, String tipo){
        try{
            return server.registraCentroVaccinale(new CentroVaccinale(nome,comune,indirizzo,tipo,0,0.0));
        }catch (RemoteException e){
            return false;
        }
    }
    /**
     * Restituisce una lista di centri vaccinali che contengono <code>nome</code> nel nome.
     * @param nome La stringa da cercare
     * @return Un'<code>ArrayList</code> di <code>CentroVaccinale</code>
     */
    public ArrayList<CentroVaccinale> cercaCentroVaccinale(String nome){
        try {
            return server.cercaCentroVaccinale(nome);
        } catch (RemoteException e) {
            return null;
        }
    }
    /**
     * Restituisce una lista di centri vaccinali con comune uguale a <code>comune</code> e tipo uguale a <code>tipo</code>.
     * @param comune Il comune del centro da cercare
     * @param tipo Il tipo del centro da cercare
     * @return Un'<code>ArrayList</code> di <code>CentroVaccinale</code>
     */
    public ArrayList<CentroVaccinale> cercaCentroVaccinale(String comune, String tipo){
        try {
            return server.cercaCentroVaccinale(comune,tipo);
        } catch (RemoteException e) {
            return null;
        }
    }
    /**
     * Restituisce Il centro vaccinale identificato da <code>nome</code> e <code>comune</code>.
     * @param nome Il nome del centro vaccinale.
     * @param comune Il comune del centro vaccinale.
     * @return Un oggetto di tipo <code>CentroVaccinale</code> se il centro esiste nel database, <code>null</code> altrimenti.
     */
    public CentroVaccinale visualizzaInfoCentroVaccinale(String nome, String comune ){
        try {
            server.updateCentriVaccinaliServ();
            return server.visualizzaInfoCentroVaccinale(nome,comune);
        } catch (RemoteException e) {
            return null;
        }
    }
    /**
     * Inserisce un cittadino registrato nel database.
     * @param email L'indirizzo e-mail del cittadino.
     * @param user L'username del cittadino.
     * @param password La password del cittadino.
     * @param idVaccinazione L'id univoco della vaccinazione.
     * @return <code>true</code> se l'operazione va a buon fine,  <code>false</code> altrimenti.
     */
    public Boolean registraCittadino(String email, String user, String password, int idVaccinazione){
        CittadinoRegistrato cittadino=new CittadinoRegistrato(idVaccinazione,user,password,email);
        try {
            return server.registraCittadino(cittadino);
        } catch (RemoteException e) {
            return false;
        }
    }
    /**
     * Inserisce un evento avverso nel database.
     * @param sintomo Il sintomo dell'evento avverso.
     * @param severita La severità dell'evento (da 1 a 5).
     * @param note Eventuali note relative all'evento (max.: 256 caratteri);
     * @param nome Il nome del centro vaccinale in cui è stata effettuata la vaccinazione che ha provocato l'evento.
     * @param comune Il comune del centro vaccinale.
     * @return <code>true</code> se l'operazione va a buon fine,  <code>false</code> altrimenti.
     */
    public Boolean inserisciEventoAvverso(String sintomo,int severita, String note,String nome, String comune){
        EventoAvverso evento=new EventoAvverso(sintomo,utente.getIdVaccinazione(),severita,note,nome,comune);
        try {
            return server.newEventoAvverso(evento);
        } catch (RemoteException e) {
            return false;
        }
    }
    /**
     * Restituisce il cittadino registrato identificato da <code>userId</code>.
     * @param userId L'username del cittadino.
     * @return Un oggetto di tipo<code>CittadinoRegistrato</code> se il cittadino esiste nel database, <code>null</code> altrimenti.
     */
    public  CittadinoRegistrato visualizzaInfoUtente(String userId){
        try {
            return server.visualizzaInfoCittadinoRegistrato(userId);
        } catch (RemoteException e) {
            e.printStackTrace();
            return null;
        }
    }
    public Boolean registraVaccinato(int idVaccinazione, String cf, String nome, String nomeCentro, String comuneCentro, Date data,String tipo){
        try{
            return server.registraVaccinato(new Vaccinato(idVaccinazione,cf,nome,nomeCentro,comuneCentro,data,tipo));
        } catch (RemoteException e) {
            return false;
        }
    }
    /**
     * Restituisce il Vaccinato identificato da <code>idVaccinazione</code>.
     * @param idVaccinazione L'id univoco della vaccinazione.
     * @return Un oggetto di tipo<code>Vaccinato</code> se il vaccinato esiste nel database, <code>null</code> altrimenti.
     */
    public  Vaccinato visualizzaInfoVaccinato(int idVaccinazione){
        try {
            return server.visualizzaInfoVaccinato(idVaccinazione);
        } catch (RemoteException e) {
            return null;
        }
    }
    /**
     *  Restituisce una lista di eventi avversi relativi all'utente <code>id</code>.
     * @param idVaccinazione L'user id del cittadino
     * @return Un'<code>ArrayList</code> di <code>EventoAvverso</code>
     */
    public ArrayList<EventoAvverso> visualizzaEventiAvversi(int idVaccinazione){
        try {
            return server.eventiAvversi(idVaccinazione);
        } catch (RemoteException e) {
            return null;
        }
    }
    /**
     * Restituisce i dati aggregati relativi al centro vaccinale identificato da <code>nome</code> e <code>comune</code>.
     * @param nome Il nome del centro vaccinale
     * @param comune il comune del centro vaccinale
     * @return Un oggetto di tipo<code>AggregazioneEventi</code> se gli eventi relativi al centro specificato esistono nel database, <code>null</code> altrimenti.
     */
    public  ArrayList<AggregazioneEventi> visualizzaAggregazioneEventi(String nome, String comune){
        try {
            server.updateAggregazioneEventiServ();
            return server.aggregazioniEventi(nome,comune);
        } catch (RemoteException e) {
            return null;
        }

    }

    /**
     * Verifica se un utente è correntemente collegato.
     * @return <code>true</code> se un utente è loggato, <code>false</code> altrimenti.
     */
    public Boolean isLoggedIn(String nome, String comune){
        return logged && nome.equals(vaccinato.getNomeCentro()) && comune.equals(vaccinato.getComuneCentro());
    }
    public Boolean isAdmin(){
        return admin;
    }
}
