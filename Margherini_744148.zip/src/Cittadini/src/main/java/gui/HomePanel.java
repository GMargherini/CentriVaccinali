/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.Objects;
import javax.imageio.ImageIO;
import javax.swing.*;

public class HomePanel extends JPanel implements ActionListener{

	private final Gui container;

	/**
	 * Genera il panel iniziale.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 */
	public HomePanel(Gui container, Cittadini client) {
		this.container=container;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS) );
		JButton search=new JButton("Cerca un centro vaccinale");
		JButton newcentro=new JButton("Inserisci un nuovo centro vaccinale");
		JButton newvaccinato=new JButton("Inserisci un nuovo vaccinato");
		Image image;
		try {
			image = ImageIO.read(Objects.requireNonNull(HomePanel.class.getResource("/Immagine_vaccinazione.jpg"))).getScaledInstance(500,300,java.awt.Image.SCALE_SMOOTH);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		JLabel imageLabel =new JLabel(new ImageIcon(image));

		imageLabel.setAlignmentX(CENTER_ALIGNMENT);
		imageLabel.setAlignmentY(CENTER_ALIGNMENT);
		add(imageLabel);
		add(Box.createRigidArea(new Dimension(20,20)));
		search.setAlignmentX(CENTER_ALIGNMENT);
		search.setAlignmentY(CENTER_ALIGNMENT);
    	add(search);
		if(client.isAdmin()){
			add(Box.createRigidArea(new Dimension(0,20)));
			newcentro.setActionCommand("centro");
			newcentro.addActionListener(this);
			newcentro.setAlignmentX(CENTER_ALIGNMENT);
			add(newcentro);
			add(Box.createRigidArea(new Dimension(0,20)));
			newvaccinato.setActionCommand("vaccinato");
			newvaccinato.addActionListener(this);
			newvaccinato.setAlignmentX(CENTER_ALIGNMENT);
			add(newvaccinato);
		}
    	
    	setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    	search.setActionCommand("search");
    	search.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		Object command=e.getActionCommand();
		if(command.equals("search")) {
			container.changePanel("search");
		}
		if(command.equals("centro")){
			container.changePanel("nuovocentro");
		}
		if(command.equals("vaccinato")){
			container.changePanel("nuovovaccinato");
		}
	}
}
