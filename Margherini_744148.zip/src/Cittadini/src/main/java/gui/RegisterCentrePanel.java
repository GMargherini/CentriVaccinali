/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterCentrePanel extends JPanel implements ActionListener {
	private final Gui container;
	private final Cittadini client;
	private final JTextField nomeTextField=new JTextField();
	private final JTextField comuneTextField=new JTextField();
	private final JTextField indirizzoTextField=new JTextField();
	private final JTextField tipoTextField=new JTextField();
	private final JLabel failLabel=new JLabel("Registrazione fallita");
	private final JButton registerButton;
	private Popup popup;

	/**
	 * Genera il panel che permette di registrare un nuovo centro vaccinale.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 */
	public RegisterCentrePanel(Gui container, Cittadini client){
		this.container =container;
		this.client=client;
		setLayout(new GridBagLayout());
		JLabel comuneLabel=new JLabel("Comune: ");
		JLabel indirizzoLabel=new JLabel("Indirizzo: ");
		JLabel nomeLabel=new JLabel("Nome: ");
		JLabel tipoLabel=new JLabel("Tipo: ");
		registerButton=new JButton("Registra centro vaccinale");
		registerButton.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {}
			@Override
			public void focusLost(FocusEvent e) {
				if(popup!=null)
					popup.hide();
			}
		});
		GridBagConstraints gbc=new GridBagConstraints();

		setBorder(BorderFactory.createEmptyBorder(10,200,60,200));

		nomeLabel.setHorizontalAlignment(JLabel.CENTER);
		comuneLabel.setHorizontalAlignment(JLabel.CENTER);
		indirizzoLabel.setHorizontalAlignment(JLabel.CENTER);
		tipoLabel.setHorizontalAlignment(JLabel.CENTER);
		failLabel.setHorizontalAlignment(JLabel.CENTER);
		gbc.insets=new Insets(10,10,10,10);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridy=0;
		gbc.weightx=0.25;
		add(nomeLabel,gbc);
		gbc.weightx=1;
		add(nomeTextField,gbc);

		gbc.gridy=1;
		gbc.weightx=0.25;
		add(comuneLabel,gbc);
		gbc.weightx=1;
		add(comuneTextField,gbc);

		gbc.gridy=2;
		gbc.weightx=0.25;
		add(indirizzoLabel,gbc);
		gbc.weightx=1;
		add(indirizzoTextField,gbc);
		gbc.gridy=3;
		gbc.weightx=0.25;
		add(tipoLabel,gbc);
		gbc.weightx=1;
		add(tipoTextField,gbc);

		gbc=new GridBagConstraints();
		gbc.insets=new Insets(10,10,10,10);
		gbc.gridy=7;
		gbc.gridx=0;
		gbc.gridwidth=GridBagConstraints.REMAINDER;

		add(registerButton,gbc);
		registerButton.setActionCommand("register");
		registerButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("register")){
			PopupFactory pf=new PopupFactory();
			Boolean success=false;
			if(!nomeTextField.getText().equals("")&&
					!comuneTextField.getText().equals("")&&
					!indirizzoTextField.getText().equals("")&&
					!tipoTextField.getText().equals("")){
				success=client.registraCentroVaccinale(
						nomeTextField.getText(),
						comuneTextField.getText(),
						indirizzoTextField.getText(),
						tipoTextField.getText()
				);
			}
			if (!success){
				failLabel.setText("Registrazione centro fallita");
				popup = pf.getPopup(this,failLabel,registerButton.getLocationOnScreen().x,registerButton.getLocationOnScreen().y+50);
				popup.show();
			}else {
				nomeTextField.setText("");
				comuneTextField.setText("");
				indirizzoTextField.setText("");
				tipoTextField.setText("");
				container.changePanel("home");
			}
		}
	}
}
