/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.*;

public class RegisterVaccinatedPanel extends JPanel implements ActionListener {
	private final Gui container;
	private final Cittadini client;
	private final JTextField comuneCentroTextField =new JTextField();
	private final JTextField idTextField=new JTextField();
	private final JTextField nomeTextField=new JTextField();
	private final JTextField nomeCentroTextField =new JTextField();
	private final JTextField cfTextField=new JTextField();
	private final JTextField dataTextField=new JTextField();
	private final JTextField tipoTextField=new JTextField();
	private final JLabel failLabel=new JLabel("Registrazione fallita");
	private final JButton registerButton;
	private Popup popup;

	/**
	 * Genera il panel che permette di registrare un nuovo vaccinato.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 */
	public RegisterVaccinatedPanel(Gui container, Cittadini client){
		this.container =container;
		this.client=client;
		setLayout(new GridBagLayout());
		JLabel idLabel=new JLabel("ID vaccinazione:");
		JLabel cfLabel=new JLabel("Codice fiscale:");
		JLabel nomeLabel=new JLabel("Nome e cognome:");
		JLabel nomeCentroLabel=new JLabel("Nome centro vaccinale:");
		JLabel comuneCentroLabel=new JLabel("Comune centro vaccinale:");
		JLabel dataLabel=new JLabel("Data vaccinazione (gg/mm/aaaa):");
		JLabel tipoLabel=new JLabel("Tipo vaccino:");



		registerButton=new JButton("Registra vaccinato");
		registerButton.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {}
			@Override
			public void focusLost(FocusEvent e) {
				if(popup!=null)
					popup.hide();
			}
		});
		GridBagConstraints gbc=new GridBagConstraints();

		setBorder(BorderFactory.createEmptyBorder(10,200,60,200));

		nomeCentroLabel.setHorizontalAlignment(JLabel.CENTER);
		comuneCentroLabel.setHorizontalAlignment(JLabel.CENTER);
		nomeLabel.setHorizontalAlignment(JLabel.CENTER);
		dataLabel.setHorizontalAlignment(JLabel.CENTER);
		cfLabel.setHorizontalAlignment(JLabel.CENTER);
		idLabel.setHorizontalAlignment(JLabel.CENTER);
		tipoLabel.setHorizontalAlignment(JLabel.CENTER);
		failLabel.setHorizontalAlignment(JLabel.CENTER);
		gbc.insets=new Insets(10,10,10,10);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.gridy=0;
		gbc.weightx=0.25;
		add(nomeLabel,gbc);
		gbc.weightx=1;
		add(nomeTextField,gbc);
		gbc.gridy=1;
		gbc.weightx=0.25;
		add(cfLabel,gbc);
		gbc.weightx=1;
		add(cfTextField,gbc);
		gbc.gridy=2;
		gbc.weightx=0.25;
		add(nomeCentroLabel,gbc);
		gbc.weightx=1;
		add(nomeCentroTextField,gbc);
		gbc.gridy=3;
		gbc.weightx=0.25;
		add(comuneCentroLabel,gbc);
		gbc.weightx=1;
		add(comuneCentroTextField,gbc);
		gbc.gridy=4;
		gbc.weightx=0.25;
		add(dataLabel,gbc);
		gbc.weightx=1;
		add(dataTextField,gbc);
		gbc.gridy=5;
		gbc.weightx=0.25;
		add(tipoLabel,gbc);
		gbc.weightx=1;
		add(tipoTextField,gbc);
		gbc.gridy=6;
		gbc.weightx=0.25;
		add(idLabel,gbc);
		gbc.weightx=1;
		add(idTextField,gbc);

		gbc=new GridBagConstraints();
		gbc.insets=new Insets(10,10,10,10);
		gbc.gridy=7;
		gbc.gridx=0;
		gbc.gridwidth=GridBagConstraints.REMAINDER;

		add(registerButton,gbc);
		registerButton.setActionCommand("register");
		registerButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getActionCommand().equals("register")){
			PopupFactory pf=new PopupFactory();
			Boolean success=false;
			try{
				DateFormat df=new SimpleDateFormat("dd/MM/yyyy");
				success=client.registraVaccinato(
						Integer.parseInt(idTextField.getText()),
						cfTextField.getText(),
						nomeTextField.getText(),
						nomeCentroTextField.getText(),
						comuneCentroTextField.getText(),
						df.parse(dataTextField.getText()),
						tipoTextField.getText()
				);
			} catch (Exception ex) {
				failLabel.setText("Dati non validi");
				popup = pf.getPopup(this,failLabel,registerButton.getLocationOnScreen().x-20,registerButton.getLocationOnScreen().y+50);
				popup.show();
			}
			if (!success){
				failLabel.setText("Registrazione vaccinato fallita");
				popup = pf.getPopup(this,failLabel,registerButton.getLocationOnScreen().x-20,registerButton.getLocationOnScreen().y+50);
				popup.show();
			}else {
				idTextField.setText("");
				comuneCentroTextField.setText("");
				nomeTextField.setText("");
				nomeCentroTextField.setText("");
				cfTextField.setText("");
				dataTextField.setText("");
				tipoTextField.setText("");
				container.changePanel("home");
			}
		}
	}
}
