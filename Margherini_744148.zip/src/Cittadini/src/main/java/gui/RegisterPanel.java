/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import datamodel.CittadinoRegistrato;
import datamodel.Vaccinato;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class RegisterPanel extends JPanel implements ActionListener {
    private final Gui container;
    private final Cittadini client;
    private final JTextField userTextField=new JTextField();
    private final JPasswordField passwordField =new JPasswordField();
    private final JPasswordField passwordField2=new JPasswordField();
    private final JTextField idTextField=new JTextField();
    private final JTextField nomeTextField=new JTextField();
    private final JTextField emailTextField=new JTextField();
    private final JTextField cfTextField=new JTextField();
    private final JLabel failLabel=new JLabel("Registrazione fallita");
    private final JButton registerButton;
    private Popup popup;

    /**
     * Genera il panel che permette di registrarsi.
     * @param container Il frame che deve contenere il panel.
     * @param client La classe che comunica con il server.
     */
    public RegisterPanel(Gui container, Cittadini client){
        this.container =container;
        this.client=client;
        setLayout(new GridBagLayout());
        JLabel idLabel=new JLabel("ID vaccinazione: ");
        JLabel userLabel=new JLabel("Username: ");
        JLabel passwordLabel=new JLabel("Password: ");
        JLabel passwordLabel2=new JLabel("Ripetere password:");
        JLabel nomeLabel=new JLabel("Nome e cognome: ");
        JLabel emailLabel=new JLabel("e-mail: ");
        JLabel cfLabel=new JLabel("Codice fiscale: ");

        registerButton=new JButton("Registrati");
        registerButton.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {}
            @Override
            public void focusLost(FocusEvent e) {
                if(popup!=null)
                    popup.hide();
            }
        });
        GridBagConstraints gbc=new GridBagConstraints();

        setBorder(BorderFactory.createEmptyBorder(10,200,60,200));

        userLabel.setHorizontalAlignment(JLabel.CENTER);
        passwordLabel.setHorizontalAlignment(JLabel.CENTER);
        nomeLabel.setHorizontalAlignment(JLabel.CENTER);
        emailLabel.setHorizontalAlignment(JLabel.CENTER);
        cfLabel.setHorizontalAlignment(JLabel.CENTER);
        idLabel.setHorizontalAlignment(JLabel.CENTER);
        failLabel.setHorizontalAlignment(JLabel.CENTER);
        gbc.insets=new Insets(10,10,10,10);
        gbc.fill=GridBagConstraints.HORIZONTAL;
        gbc.gridy=0;
        gbc.weightx=0.25;
        add(nomeLabel,gbc);
        gbc.weightx=1;
        add(nomeTextField,gbc);
        gbc.gridy=1;
        gbc.weightx=0.25;
        add(cfLabel,gbc);
        gbc.weightx=1;
        add(cfTextField,gbc);
        gbc.gridy=2;
        gbc.weightx=0.25;
        add(emailLabel,gbc);
        gbc.weightx=1;
        add(emailTextField,gbc);
        gbc.gridy=3;
        gbc.weightx=0.25;
        add(userLabel,gbc);
        gbc.weightx=1;
        add(userTextField,gbc);
        gbc.gridy=4;
        gbc.weightx=0.25;
        add(passwordLabel,gbc);
        gbc.weightx=1;
        add(passwordField,gbc);
        gbc.gridy=5;
        gbc.weightx=0.25;
        add(passwordLabel2,gbc);
        gbc.weightx=1;
        add(passwordField2,gbc);
        gbc.gridy=6;
        gbc.weightx=0.25;
        add(idLabel,gbc);
        gbc.weightx=1;
        add(idTextField,gbc);

        gbc=new GridBagConstraints();
        gbc.insets=new Insets(10,10,10,10);
        gbc.gridy=7;
        gbc.gridx=0;
        gbc.gridwidth=GridBagConstraints.REMAINDER;

        add(registerButton,gbc);
        registerButton.setActionCommand("register");
        registerButton.addActionListener(this);
    }
    /**
     * Verifica che le informazioni inserite corrispondano a quelle di uno dei vaccinati presenti nel database.
     * @return <code>true</code> se le credenziali sono valide, <code>false</code> altrimenti.
     */
    private Boolean checkVaccinato() {
        Vaccinato vaccinato;
        try{
            vaccinato=client.visualizzaInfoVaccinato(Integer.parseInt(idTextField.getText()));
            if (vaccinato==null){
                throw new NullPointerException() ;
            }
        }
        catch(NumberFormatException | NullPointerException e){
            return false;
        }
        return vaccinato.getIdVaccinazione()==Integer.parseInt(idTextField.getText()) &&
                vaccinato.getCodiceFiscale().equals(cfTextField.getText().toUpperCase()) &&
                vaccinato.getNomeCognome().equalsIgnoreCase(nomeTextField.getText());
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("register")){
            PopupFactory pf=new PopupFactory();
            Boolean success;
            if(String.valueOf(passwordField.getPassword()).equals(String.valueOf(passwordField2.getPassword()))){
                if(checkVaccinato()){
                    success=client.registraCittadino(
                            emailTextField.getText(),
                            userTextField.getText(),
                            String.valueOf(passwordField.getPassword()),
                            Integer.parseInt(idTextField.getText())
                    );
                    if (!success){
                        failLabel.setText("Registrazione fallita");
                        popup = pf.getPopup(this,failLabel,registerButton.getLocationOnScreen().x-20,registerButton.getLocationOnScreen().y+50);
                        popup.show();
                    }else {
                        client.setUtente(new CittadinoRegistrato(Integer.parseInt(idTextField.getText()),userTextField.getText(),String.valueOf(passwordField.getPassword()),emailTextField.getText()));
                        container.logIn(userTextField.getText());
                        idTextField.setText("");
                        userTextField.setText("");
                        passwordField.setText("");
                        passwordField2.setText("");
                        nomeTextField.setText("");
                        emailTextField.setText("");
                        cfTextField.setText("");
                        container.changePanel("user");
                    }
                }
                else {
                    failLabel.setText("Registrazione fallita");
                    popup = pf.getPopup(this,failLabel,registerButton.getLocationOnScreen().x-20,registerButton.getLocationOnScreen().y+50);
                    popup.show();
                }
            }
            else {
                failLabel.setText("Le password inserite non corrispondono");
                popup = pf.getPopup(this,failLabel,registerButton.getLocationOnScreen().x-60,registerButton.getLocationOnScreen().y+50);
                popup.show();
            }
        }
    }
}
