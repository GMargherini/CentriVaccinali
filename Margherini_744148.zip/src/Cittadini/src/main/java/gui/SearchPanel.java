/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import datamodel.*;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;


public class SearchPanel extends JPanel implements ActionListener{
	private final Gui container;
	private final Cittadini client;
	private String[][] data;
	private Boolean ricercaPerNome=true;
	private final JPanel cards=new JPanel(new CardLayout());
	private CardLayout cardLayout=new CardLayout();
	private final JComboBox<String> cb=new JComboBox<>();
	private final JTextField searchNome;
	private final JTextField searchComune;
	private final JTextField searchTipo;
	private final JTable resultTable;
	private final String[] columnNames= {"Nome","Comune"};

	/**
	 * Genera il panel che permette di effettuare la ricerca di un centro vaccinale.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 */
	public SearchPanel(Gui container, Cittadini client) {

		this.container=container;
		this.client=client;
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		JButton searchBtn1 = new JButton("cerca");
		JButton searchBtn2 = new JButton("cerca");
		searchNome=new JTextField();
		searchComune=new JTextField();
		searchTipo=new JTextField();

		searchNome.setMaximumSize(new Dimension(200,20));
		searchComune.setMaximumSize(new Dimension(200,20));
		searchTipo.setMaximumSize(new Dimension(200,20));
		data=new String[0][0];
		resultTable=new JTable(data,columnNames) ;
		JScrollPane scrollPane = new JScrollPane(resultTable);
		JPanel top=new JPanel();
		JPanel middle=new JPanel();
		JPanel nome=new JPanel();
		JPanel comuneTipo=new JPanel();
		
		resultTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		resultTable.setDefaultEditor(Object.class, null);
		resultTable.getSelectionModel().addListSelectionListener(new TableSelectionHandler());
		add(scrollPane);
		updateTable(client.cercaCentroVaccinale(""));

		top.setLayout(new BoxLayout(top, BoxLayout.X_AXIS));
		top.add(Box.createGlue());
		top.add(cb);
		
		nome.setLayout(new BoxLayout(nome, BoxLayout.X_AXIS));
		nome.add(Box.createRigidArea(new Dimension(600,0)));
		nome.add(searchNome);
		nome.add(Box.createRigidArea(new Dimension(10,10)));
		nome.add(searchBtn1);
		
		comuneTipo.setLayout(new BoxLayout(comuneTipo, BoxLayout.X_AXIS));
		comuneTipo.add(Box.createRigidArea(new Dimension(400,0)));
		comuneTipo.add(searchComune);
		comuneTipo.add(Box.createRigidArea(new Dimension(10,10)));
		comuneTipo.add(searchTipo);
		comuneTipo.add(Box.createRigidArea(new Dimension(10,10)));
		comuneTipo.add(searchBtn2);
		searchBtn1.setActionCommand("search");
		searchBtn2.setActionCommand("search");
		searchBtn1.addActionListener(this);
		searchBtn2.addActionListener(this);
		middle.setLayout(cardLayout);
		cards.add(nome,"Ricerca per nome");
		cards.add(comuneTipo,"Ricerca per comune e tipo");
		cardLayout=(CardLayout) cards.getLayout();
		middle.add(cards);
		
		cb.addItem("Ricerca per nome");
		cb.addItem("Ricerca per comune e tipo");
		cb.addActionListener(this);
		
		setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		add(top);
		add(Box.createRigidArea(new Dimension(20,20)));
		add(middle);
		add(Box.createRigidArea(new Dimension(20,20)));
		add(scrollPane);

	}
	public void actionPerformed(ActionEvent e) {
		Object command=e.getActionCommand();
		if(command.equals("search")) {
			ArrayList<CentroVaccinale>result;
			if(ricercaPerNome){
				result=client.cercaCentroVaccinale(searchNome.getText());
			}
			else{
				result=client.cercaCentroVaccinale(searchComune.getText(),searchTipo.getText().toLowerCase());
			}
			updateTable(result);
		}
		if(command.equals("comboBoxChanged")) {
			searchNome.setText("");
			searchTipo.setText("");
			searchComune.setText("");
			cardLayout.show(cards, cb.getSelectedItem().toString());
			ricercaPerNome=cb.getSelectedItem().toString().equals("Ricerca per nome");
		}
	}
	private void updateTable(ArrayList<CentroVaccinale> result){

		int size=result==null?0:result.size();
		data=new String[size][2];
		for(int i=0;i<size;i++){
			String[]temp=result.get(i).toArray();
			data[i][0]=temp[0];
			data[i][1]=temp[1];
		}
		DefaultTableModel model=new  DefaultTableModel(data,columnNames);
		resultTable.setModel(model);
	}

	private class TableSelectionHandler implements ListSelectionListener{

		public void valueChanged(ListSelectionEvent e) {
			if(! e.getValueIsAdjusting()) {
				int row=resultTable.getSelectedRow();
				String nome= (String) resultTable.getValueAt(row, 0);
				String comune=(String) resultTable.getValueAt(row, 1);
				container.changePanel("centre",nome,comune);
			}
		}
	}
}
