/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import datamodel.*;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class LoginPanel extends JPanel implements ActionListener{

	private final Gui container;
	private final Cittadini client;
	private final JTextField userTextField;
	private final JPasswordField passwordTextField;
	private final JLabel failLabel=new JLabel();
	private final JButton loginButton;
	private Popup popup;

	/**
	 * Genera il panel che permette di effettuare l'accesso.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 */
	public LoginPanel(Gui container, Cittadini client) {
		this.container = container;
		this.client=client;
		setLayout(new GridBagLayout());
		JLabel userLabel=new JLabel("Username: ");
		JLabel passwordLabel=new JLabel("Password: ");

		userTextField=new JTextField();
		passwordTextField=new JPasswordField();
		loginButton=new JButton("Accedi");
		loginButton.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {}
			@Override
			public void focusLost(FocusEvent e) {
				if(popup!=null)
					popup.hide();
			}
		});
		GridBagConstraints gbc=new GridBagConstraints();
		
		setBorder(BorderFactory.createEmptyBorder(10,200,60,200));
		userLabel.setHorizontalAlignment(JLabel.CENTER);
		passwordLabel.setHorizontalAlignment(JLabel.CENTER);
		gbc.insets=new Insets(10,10,10,10);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.anchor=GridBagConstraints.PAGE_START;
		gbc.gridy=0;
		gbc.weightx=0.25;
		add(userLabel,gbc);
		gbc.weightx=1;
		add(userTextField,gbc);
		gbc.gridy=1;
		gbc.weightx=0.25;
		add(passwordLabel,gbc);
		gbc.weightx=1;
		add(passwordTextField,gbc);
		
		gbc=new GridBagConstraints();
		gbc.insets=new Insets(10,10,10,10);
		gbc.gridy=2;
		gbc.gridx=0;
		gbc.gridwidth=GridBagConstraints.REMAINDER;
		add(loginButton,gbc);
		loginButton.setActionCommand("login");
		loginButton.addActionListener(this);
		
	}

	/**
	 * Verifica che l'utente esista e che la password sia corretta.
	 * @param id L'username dell'utente.
	 * @param password La password
	 * @return <code>true</code> se le credenziali inserite sono corrette, <code>false</code> altrimenti.
	 */
	private Boolean isUserValid(String id,String password) {
		CittadinoRegistrato user=client.visualizzaInfoUtente(id);
		if(user!=null && password.equals(user.getPassword())){
			client.setUtente(user);
			return true;
		}
		return false;
	}
	public void actionPerformed(ActionEvent e) {
		String command=e.getActionCommand();
		if(command.equals("login") && isUserValid(userTextField.getText(), String.valueOf(passwordTextField.getPassword()))) {
			container.logIn(userTextField.getText());
			userTextField.setText("");
			passwordTextField.setText("");
			if(userTextField.getText().equals("admin")){
				container.changePanel("home");
			}
			container.changePanel("user");
		}
		else{
			PopupFactory pf=new PopupFactory();
			failLabel.setText("Accesso fallito");
			popup = pf.getPopup(this,failLabel,loginButton.getLocationOnScreen().x-10,loginButton.getLocationOnScreen().y+50);
			popup.show();
		}
	}
}
