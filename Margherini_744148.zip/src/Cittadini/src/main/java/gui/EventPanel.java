/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Objects;

public class EventPanel extends JPanel implements ActionListener {
	private final Gui container;
	private final Cittadini client;
	private final String nomeCentro;
	private final String comuneCentro;
	private final JComboBox<String> symptomComboBox;
	private final JTextField severityTextField;
	private final JTextField notesTextField;
	private final JButton signalButton;
	private Popup popup;

	/**
	 * Genera un panel che permette di inserire un evento avverso.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 * @param nome Il nome del centro vaccinale relativo all'evento avverso.
	 * @param comune Il comune del centro vaccinale.
	 */
	public EventPanel(Gui container, Cittadini client,String nome, String comune) {
		this.container=container;
		this.client=client;
		nomeCentro=nome;
		comuneCentro=comune;


		setLayout(new GridBagLayout());
		JLabel symptomLabel=new JLabel("Sintomo:");
		JLabel severityLabel=new JLabel("Severità (da 1 a 5):");
		JLabel notesLabel=new JLabel("Note (Max. 256 caratteri):");
		String[] sintomi = {"mal di testa", "febbre", "dolori muscolari e articolari", "linfoadenopatia", "tachicardia", "crisi ipertensiva"};
		symptomComboBox =new JComboBox<>(sintomi);
		severityTextField=new JTextField();
		notesTextField=new JTextField();
		signalButton=new JButton("Inserisci evento");
		GridBagConstraints gbc=new GridBagConstraints();

		setBorder(BorderFactory.createEmptyBorder(10,200,60,200));
		symptomLabel.setHorizontalAlignment(JLabel.CENTER);
		severityLabel.setHorizontalAlignment(JLabel.CENTER);
		gbc.insets=new Insets(10,10,10,10);
		gbc.fill=GridBagConstraints.HORIZONTAL;
		gbc.anchor=GridBagConstraints.PAGE_START;
		gbc.gridy=0;
		gbc.weightx=0.25;
		add(symptomLabel,gbc);
		gbc.weightx=1;
		add(symptomComboBox,gbc);
		gbc.gridy=1;
		gbc.weightx=0.25;
		add(severityLabel,gbc);
		gbc.weightx=1;
		add(severityTextField,gbc);
		gbc.gridy=2;
		gbc.weightx=0.25;
		add(notesLabel,gbc);
		gbc.weightx=1;
		add(notesTextField,gbc);

		gbc=new GridBagConstraints();
		gbc.insets=new Insets(10,10,10,10);
		gbc.gridy=3;
		gbc.gridx=0;
		gbc.gridwidth=GridBagConstraints.REMAINDER;
		add(signalButton,gbc);
		signalButton.addActionListener(this);
		signalButton.addFocusListener(new FocusListener() {
			@Override
			public void focusGained(FocusEvent e) {}
			@Override
			public void focusLost(FocusEvent e) {
				if(popup!=null)
					popup.hide();
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		PopupFactory pf=new PopupFactory();
		Boolean success;
		try{
			success=client.inserisciEventoAvverso(
					Objects.requireNonNull(symptomComboBox.getSelectedItem()).toString(),
					Integer.parseInt(severityTextField.getText()),
					notesTextField.getText(),
					nomeCentro,
					comuneCentro
			);
			if(!success){
				throw new Exception();
			}
			severityTextField.setText("");
			notesTextField.setText("");
			container.changePanel("centre",nomeCentro,comuneCentro);
		}
		catch(Exception e1){
			JLabel failLabel=new JLabel("Errore nell'inserimento dell'evento");
			popup = pf.getPopup(this, failLabel, signalButton.getLocationOnScreen().x - 20, signalButton.getLocationOnScreen().y + 50);
			popup.show();
		}

	}
}
