/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Gui extends JFrame implements ActionListener{

	private final Cittadini client;
	private JPanel loginPanel;
	private JPanel registerPanel;
	private final JPanel homePanel;
	private final JMenu menuUtente;
	private final JMenuItem login;
	private final JMenuItem register;
	private final JPanel cards=new JPanel(new CardLayout());
	private CardLayout cardLayout=new CardLayout();

	/**
	 * Genera il frame per l'interfaccia grafica.
	 * @param cittadini La classe principale
	 */
	public Gui(Cittadini cittadini) {
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException |
				 UnsupportedLookAndFeelException e) {
			throw new RuntimeException(e);
		}
		client=cittadini;
		int width = 900;
		int height = 700;
		homePanel = new HomePanel(this,client);

		JMenuBar menuBar=new JMenuBar();
		JButton home=new JButton("Home");

		setLayout(cardLayout);
		cards.add(homePanel, "home");


		cardLayout.setVgap(10);
		cardLayout.setHgap(10);
		cardLayout=(CardLayout) cards.getLayout();
		add(cards);

    	menuUtente=new JMenu("Utente");
    	login=new JMenuItem("accedi");
		register=new JMenuItem("registrati");

    	setTitle("Cittadini");
    	home.setOpaque(false);
    	home.setContentAreaFilled(false);
    	home.setBorderPainted(false);

    	menuBar.add(home);
    	menuBar.add(Box.createHorizontalGlue());
    	menuBar.add(menuUtente);
    	menuUtente.add(login);
		menuUtente.add(register);
    	home.setActionCommand("home");
    	home.addActionListener(this);
    	login.setActionCommand("login");
    	login.addActionListener(this);
		register.setActionCommand("register");
		register.addActionListener(this);
    	setJMenuBar(menuBar);

		setSize(width, height);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		changePanel("home");
		setVisible(true);
		setResizable(false);
	}

	/**
	 * Modifica l'interfaccia a seguito di un accesso.
	 * @param userId L'username dell'utente che ha effettuato l'accesso.
	 */
	protected void logIn(String userId){
		menuUtente.setText(userId);
		login.setText("Info utente");
		login.setActionCommand("user");
		register.setText("Esci");
		register.setActionCommand("logout");
		menuUtente.revalidate();
		menuUtente.repaint();
	}

	/**
	 * Riporta l'interfaccia alle impostazioni di base a seguito del log-out da parte dell'utente.
	 */
	protected void logOut(){
		client.setUtente(null);
		menuUtente.setText("Utente");
		login.setText("accedi");
		register.setText("registrati");
		login.setActionCommand("login");
		register.setActionCommand("register");
		menuUtente.revalidate();
		menuUtente.repaint();
		changePanel("home");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String command=e.getActionCommand();
		switch (command) {
			case "login" -> {
				if (loginPanel == null) {
					loginPanel = new LoginPanel(this, client);
					cards.add(loginPanel, command);
				}
				changePanel(command);
			}
			case "register" -> {
				if (registerPanel == null) {
					registerPanel = new RegisterPanel(this, client);
					cards.add(registerPanel, command);
				}
				changePanel(command);
			}
			case "user" -> changePanel(command);
			case "logout" -> logOut();
			case "home" -> changePanel("home");
		}
		cardLayout.show(cards,command);
	}


	/**
	 * Scambia il panel correntemente visibile con quello identificato da <code>panel</code>, fornendo le informazioni sul centro vaccinale.
	 * @param panel Il nome del panel da mostrare.
	 * @param nome Il nome del centro vaccinale.
	 * @param comune Il comune del centro vaccinale.
	 */

	protected void changePanel(String panel,String nome, String comune){
		JPanel newPanel = switch (panel) {
			case "centre" -> new CentrePanel(this, client, nome, comune);
			case "event" -> new EventPanel(this, client, nome, comune);
			default -> homePanel;
		};
		cards.add(newPanel,panel);
		cardLayout.show(cards,panel);
	}

	/**
	 * Scambia il panel correntemente visibile con quello identificato da <code>panel</code>.
	 * @param panel Il nome del panel da mostrare.
	 */
	protected void changePanel(String panel){
		JPanel newPanel = switch (panel) {
			case "search" -> new SearchPanel(this, client);
			case "user" -> new UserPanel(client, client.getUtente());
			case "login" -> loginPanel;
			case "register" -> registerPanel;
			case "nuovocentro" -> new RegisterCentrePanel(this,client);
			case "nuovovaccinato" ->new RegisterVaccinatedPanel(this,client);
			default -> new HomePanel(this,client);
		};
		cards.add(newPanel,panel);
		cardLayout.show(cards,panel);
	}

}
