/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import datamodel.CittadinoRegistrato;
import datamodel.EventoAvverso;
import datamodel.Vaccinato;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class UserPanel extends JPanel {
    private final Cittadini client;
    private final String[] columnNames= {"Sintomo","Severità","Note"};

    /**
     * Genera il panel che mostra le informazioni dell'utente
     * @param client La classe che comunica con il server.
     * @param utente L'utente di cui mostrare le informazioni.
     */
    public UserPanel( Cittadini client, CittadinoRegistrato utente){
        this.client=client;
        Vaccinato infoVaccinato = client.visualizzaInfoVaccinato(utente.getIdVaccinazione());
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS) );

        JPanel info= new JPanel(new GridLayout(3,2,50,30));
        JLabel idLabel=new JLabel("ID vaccinazione: "+ infoVaccinato.getIdVaccinazione());
        JLabel cfLabel=new JLabel("Codice fiscale: "+ infoVaccinato.getCodiceFiscale());
        JLabel nomeCognomeLabel=new JLabel("Nome e cognome: "+ infoVaccinato.getNomeCognome());
        JLabel nomeCentroLabel=new JLabel("Nome centro vaccinale: "+ infoVaccinato.getNomeCentro());
        JLabel dataLabel=new JLabel("Data vaccinazione: "+ infoVaccinato.getDataVaccinazione());
        JLabel tipoLabel=new JLabel("Tipo vaccino: "+ infoVaccinato.getTipoVaccino());

        info.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        info.add(idLabel);
        info.add(cfLabel);
        info.add(nomeCognomeLabel);
        info.add(tipoLabel);
        info.add(dataLabel);
        info.add(nomeCentroLabel);
        add(info);
        updateTable(utente);
    }
    private void updateTable(CittadinoRegistrato utente){
        ArrayList<EventoAvverso> segnalazioni = this.client.visualizzaEventiAvversi(utente.getIdVaccinazione());
        String[][] data;
        int size = segnalazioni ==null?0: segnalazioni.size();
        data = new String[size][3];
        for (int i = 0; i < size; i++) {
            String[] temp = segnalazioni.get(i).toArray();
            data[i][0] = temp[0];
            data[i][1] = temp[2];
            data[i][2] = temp[3];
        }
        JTable resultTable = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(resultTable);
        DefaultTableModel model=new  DefaultTableModel(data,columnNames);
        resultTable.setModel(model);
        resultTable.setDefaultEditor(Object.class, null);
        resultTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        add(scrollPane);
    }
}
