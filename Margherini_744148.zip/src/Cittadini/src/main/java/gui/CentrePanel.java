/*
 * Antonicelli Sandy, 744947, VA
 * Caffi Nicolò, 745391, VA
 * Margherini Giorgio, 744148, VA
 */
package gui;

import cittadini.Cittadini;
import datamodel.*;
import java.awt.*;
import java.awt.event.*;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class CentrePanel extends JPanel implements ActionListener{

	private final Gui container;
	private final Cittadini client;
	private final CentroVaccinale infoCentro;

	/**
	 * Genera un panel che mostra le informazioni di un centro vaccinale.
	 * @param container Il frame che deve contenere il panel.
	 * @param client La classe che comunica con il server.
	 * @param nome Il nome del centro vaccinale del quale mostrare le informazioni.
	 * @param comune Il comune del centro vaccinale.
	 */
	public CentrePanel(Gui container, Cittadini client, String nome, String comune) {
		this.container=container;
		this.client=client;
		DecimalFormat df=new DecimalFormat("#.#");
		df.setRoundingMode(RoundingMode.DOWN);
		infoCentro=client.visualizzaInfoCentroVaccinale(nome,comune);
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS) );

		if(checkUser()) {
			JPanel signalPanel=new JPanel();
			signalPanel.setLayout(new BoxLayout(signalPanel,BoxLayout.X_AXIS));
			JButton signal =new JButton("Segnala evento avverso");
			signal.addActionListener(this);
			signal.setActionCommand("event");
			signalPanel.add(Box.createRigidArea(new Dimension(600,0)));
			signalPanel.add(signal);
			add(signalPanel);
		}
		
		JPanel info= new JPanel(new GridLayout(3,2,50,20));
		JLabel nomeLabel=new JLabel("Nome: "+infoCentro.getNome());
		JLabel comuneLabel=new JLabel("Comune: "+infoCentro.getComune());
		JLabel indirizzoLabel=new JLabel("Indirizzo: "+infoCentro.getIndirizzo());
		JLabel tipoLabel=new JLabel("Tipo: "+infoCentro.getTipo());
		JLabel segnalazioniLabel=new JLabel("Numero segnalazioni: "+infoCentro.getTotaleSegnalazioni());
		JLabel mediaLabel=new JLabel("Severità media: "+df.format(infoCentro.getMediaGenerale()));
		
		info.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		info.add(nomeLabel);
		info.add(comuneLabel);
		info.add(indirizzoLabel);
		info.add(tipoLabel);
		info.add(segnalazioniLabel);
		info.add(mediaLabel);
		add(info);
		ArrayList<AggregazioneEventi> segnalazioni = client.visualizzaAggregazioneEventi(infoCentro.getNome(), infoCentro.getComune());
		int size= segnalazioni.size();
		String[][] data=new String[size][3];
		for(int i=0;i<size;i++){
			String[] temp=segnalazioni.get(i).toArray();
			data[i][0]=temp[0];
			data[i][1]=temp[3];
			data[i][2]=temp[4].substring(0,3);
		}

		JTable resultTable=new JTable() ;
		String[] columnNames = {"Sintomo", "Numero segnalazioni", "Severità media"};
		DefaultTableModel model=new  DefaultTableModel(data, columnNames);
		resultTable.setModel(model);
		resultTable.setDefaultEditor(Object.class, null);
		JScrollPane scrollPane=new JScrollPane(resultTable);
		add(scrollPane);
		
	}

	/**
	 * Verifica se ci sono utenti correntemente collegati.
	 * @return <code>true</code> se un utente è loggato, <code>false</code> altrimenti.
	 */
	private boolean checkUser() {
		return client.isLoggedIn(infoCentro.getNome(),infoCentro.getComune());
	}

	public void actionPerformed(ActionEvent e) {
		container.changePanel("event",infoCentro.getNome(),infoCentro.getComune());
	}
}
